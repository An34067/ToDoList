from django.db import models

# Create your models here.

class Number(models.Model):
    value = models.FloatField()
    name = models.CharField(max_length=100)
    discoverer = models.CharField(max_length=200, blank=True, null=True)

    class Meta:
        verbose_name = "Число"
        verbose_name_plural = "Числа"

    def __str__(self):
        return self.name