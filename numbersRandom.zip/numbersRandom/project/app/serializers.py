from rest_framework.serializers import ModelSerializer
from . import models

class NumberSerializer(ModelSerializer):
    class Meta:
        model = models.Number
        fields = ['value', 'name', 'discoverer']