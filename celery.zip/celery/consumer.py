from publisher import run_pipeline, run_full_distribution, urgent_alert

run_pipeline.delay()
run_full_distribution.delay()
urgent_alert.apply_async(args=["Тревога"], countdown=15)