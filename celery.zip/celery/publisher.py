from celery import Celery, chain, chord
from celery.schedules import crontab

app = Celery(
    "Celery_app",
    broker="amqp://guest:guest@localhost//",
    backend="db+sqlite:///result.sqlite3"
)

app.conf.update(
    timezone="UTC",
    time_track_started=True,
    task_acks_late=True
)

app.conf.beat_schedule = {
    "run_prepare_daily_data": {
        "task": "publisher.prepare_daily_data",
        "schedule": crontab(minute="*/2"),
    },
}

@app.task
def prepare_daily_data():
    print("Начало сбора данных....")

@app.task
def fetch_data(dummy_arg):
    return "Сырые данные"

@app.task
def process_data(raw_data):
    print(f"Обработка: {raw_data}")
    return "Обработанный отчет"

@app.task
def save_report(report):
    print(f"Сохранено: {report}")
    return True

@app.task
def run_pipeline():
    chain(
        fetch_data.s("Строка"),
        process_data.s(),
        save_report.s()
    ).apply_async()

@app.task
def notify_dean(department):
    print(f"Уведомление отправлено руководителю {department}")
    return f"OK: {department}"

@app.task
def final_summary(results):
    print(f"Финальный отчет. Результаты: {results}")

@app.task
def run_full_distribution():
    chord(
        [notify_dean.s(d) for d in ['ИТ', 'Экономика', 'Юридический']]
    )(final_summary.s())

@app.task
def urgent_alert(message):
    print(f"СРОЧНО: {message}")