from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def hello(request):
    return HttpResponse("<p>Hello everyone!</p>")

def info(request):
    return HttpResponse("Amirdzoni")