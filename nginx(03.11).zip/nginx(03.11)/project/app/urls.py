from django.urls import path
from .views import *
from app import views
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register(r'notes', NoteViewSet, basename="note")

urlpatterns = router.urls


# urlpatterns = [
#     path('', views.hello),
#     path('me/', views.info),
# ]