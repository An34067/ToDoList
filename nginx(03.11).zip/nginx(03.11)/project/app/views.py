from django.shortcuts import render
from django.http import HttpResponse
from rest_framework import viewsets
from .models import *
from .serializers import *

# Create your views here.


class NoteViewSet(viewsets.ModelViewSet):
    queryset = Note.objects.all()
    serializer_class = NoteSerializer




def hello(request):
    return HttpResponse("Hello everyone!")

def info(request):
    return HttpResponse("Amirdzoni")