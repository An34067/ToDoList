from django.shortcuts import render
from .models import *
from .serializers import *
from rest_framework.viewsets import ModelViewSet
from rest_framework.response import Response
from rest_framework.decorators import action

# Create your views here.

class ManufacturerViewSet(ModelViewSet):
    queryset = Manufacturer.objects.all()
    serializer_class = ManufacturerSerializer

class ProductViewSet(ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

    @action(methods=['GET'], detail=False, url_path='russian')
    def russian_manufacturers_list(self, request):
        queryset = self.get_queryset().filter(country='Россия')
        serializer = self.get_serializer(queryset, many=True)
        return Response(self.serializer.data)
    
    def perform_create(self, serializer):
        name = serializer.validated_data['name']
        if not name.startswitch('ООО'):
            name = 'ООО' + name
            serializer.validated_data['name'] = name
        return super().perform_create(serializer)








  
    # за все объекты
    # def list(self, request, *args, **kwargs):
    #     return super().list(request, *args, **kwargs)
    # def create(self, request, *args, **kwargs):
    #     return super().create(request, *args, **kwargs)
    
    # # за конкретный объект
    # def update(self, request, *args, **kwargs):
    #     return super().update(request, *args, **kwargs)
    # def partial_update(self, request, *args, **kwargs):
    #     return super().partial_update(request, *args, **kwargs)
    # def destroy(self, request, *args, **kwargs):
    #     return super().destroy(request, *args, **kwargs)
    # def retrieve(self, request, *args, **kwargs):
    #     return super().retrieve(request, *args, **kwargs)