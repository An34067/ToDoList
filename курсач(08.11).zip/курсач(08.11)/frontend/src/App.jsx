import { useState, useEffect } from 'react';

function App() {
  const [books, setBooks] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [page, setPage] = useState('books'); // 'books' или 'reviews'

  // Загружаем данные с бэкенда
  useEffect(() => {
    // Загрузка книг
    fetch('http://127.0.0.1:8000/books/')
      .then(res => res.json())
      .then(data => setBooks(data.data));

    // Загрузка всех отзывов
    fetch('http://127.0.0.1:8000/reviews/')
      .then(res => res.json())
      .then(data => setReviews(data.data));
  }, []);

  return (
    <div className="container">
      {/* Меню навигации */}
      <nav className="nav-menu">
        <button 
          className={page === 'books' ? 'active' : ''} 
          onClick={() => setPage('books')}
        >
          Каталог книг
        </button>
        <button 
          className={page === 'reviews' ? 'active' : ''} 
          onClick={() => setPage('reviews')}
        >
          Все отзывы
        </button>
      </nav>

      {/* --- СТРАНИЦА: КНИГИ --- */}
      {page === 'books' && (
        <>
          <h1>Каталог книг</h1>
          <div className="book-grid">
            {books.map(book => (
              <div key={book.id} className="book-card">
                {/* Если есть обложка, показываем её, иначе серый блок */}
                {book.cover_url ? (
                  <img src={book.cover_url} alt={book.title} className="book-cover" />
                ) : (
                  <div className="book-cover-placeholder">Нет обложки</div>
                )}
                <div className="book-info">
                  <h3>{book.title}</h3>
                  <p className="author-name">
                    Автор: {book.authors.map(a => a.full_name).join(', ')}
                  </p>
                  <p className="book-desc">{book.description}</p>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* --- СТРАНИЦА: ОТЗЫВЫ --- */}
      {page === 'reviews' && (
        <>
          <h1>Отзывы читателей</h1>
          <div className="reviews-list">
            {reviews.length === 0 ? (
              <p>Пока нет отзывов.</p>
            ) : (
              reviews.map(review => (
                <div key={review.id} className="review-card">
                  <div className="review-header">
                    <strong>{review.user.username}</strong>
                    <span className="review-rating">Оценка: {review.rating} / 5</span>
                  </div>
                  <p className="review-text">"{review.text}"</p>
                </div>
              ))
            )}
          </div>
        </>
      )}
    </div>
  );
}

export default App;